export const MUSCLES = [
  { id: "chest", name: "Chest" },
  { id: "back", name: "Back" },
  { id: "shoulders", name: "Shoulders" },
  { id: "arms", name: "Arms" },
  { id: "core", name: "Core" },
  { id: "legs", name: "Legs" },
  { id: "glutes", name: "Glutes" },
];
